package cp213;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

public class A04Frame extends JFrame {
//Measurements for the GUI
	public static final int HEIGHT = 600;
	public static final int WIDTH = 1000;

//All the components for the program
	public static A04Panel Panel1;
	public static A04Panel Panel2;
	public static A04Panel Panel3;
	public static A04Panel Panel4;

	public static A04Buttons add;
	public static A04Buttons del;

	public static JLabel text;

	public A04Frame() { // Main frame Layout for the program
		super("My Cool GUI");
		setSize(WIDTH, HEIGHT);
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panellayout();
		blayout();
	}

	// Method for setting the 4 panels with their id's and adding them to the main
	// frame

	public void panellayout() {
		int btext = 1;
		JPanel mpanel = new JPanel();
		mpanel.setLayout(new GridLayout(1, 4)); // Layout for main panel

		Panel1 = new A04Panel(); // Box 1
		Panel1.add(new JLabel("Box # " + btext++));
		Panel1.setBackground(Color.BLACK);
		Panel1.setVisible(false);
		mpanel.add(Panel1);

		Panel2 = new A04Panel();// Box 2
		Panel2.add(new JLabel("Box # " + btext++));
		Panel2.setBackground(Color.YELLOW);
		Panel2.setVisible(false);
		mpanel.add(Panel2);

		Panel3 = new A04Panel(); // Box 3
		Panel3.add(new JLabel("Box # " + btext++));
		Panel3.setBackground(Color.BLACK);
		Panel3.setVisible(false);
		mpanel.add(Panel3);

		Panel4 = new A04Panel(); // Box 4
		Panel4.add(new JLabel("Box # " + btext++));
		Panel4.setBackground(Color.YELLOW);
		Panel4.setVisible(false);
		mpanel.add(Panel4);
		this.add(mpanel, BorderLayout.CENTER);
	}

	// Method for button layout for the program to be in the main frame

	public void blayout() {
		JPanel buttonPanel = new JPanel(); // Panel to place the 2 buttons

		buttonPanel.setLayout(new FlowLayout());

		A04Listeners a = new A04Listeners(); // Registering the buttons to action listener

		add = new A04Buttons("Create a Box"); // Main 2 buttons for the gui
		add.addActionListener(a);
		add.setEnabled(true);
		add.setBackground(Color.GREEN);
		buttonPanel.add(add);

		del = new A04Buttons("Delete a Box");
		del.addActionListener(a);
		del.setEnabled(false);
		del.setBackground(Color.WHITE);
		buttonPanel.add(del);

		text = new JLabel("Number of boxes: 0");
		text.updateUI();
		buttonPanel.add(text);
		this.add(buttonPanel, BorderLayout.NORTH); // adds buttons to the top
		setVisible(true);
	}

}
