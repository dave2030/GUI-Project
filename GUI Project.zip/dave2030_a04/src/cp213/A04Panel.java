package cp213;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class A04Panel extends JPanel {
	private int count;

	public int getCount() {
		return this.count;
	}

	public void setCount(int i) {
		count = i;
	}
}
