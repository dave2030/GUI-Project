package cp213;

public class A04 {

	public static void main(String[] args) {
		A04Frame runit = new A04Frame();

	}

}
