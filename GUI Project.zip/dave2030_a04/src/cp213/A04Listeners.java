package cp213;

import java.awt.*;
import java.awt.event.*;

public class A04Listeners implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		String b = e.getActionCommand();

		if (b.equals("Create a Box") && A04Frame.Panel1.getBackground() == Color.BLACK) { // Adds the first box
			A04Frame.Panel1.setBackground(Color.YELLOW);
			A04Frame.Panel1.setVisible(true);
			A04Frame.del.setEnabled(true);
			A04Frame.text.setText("Number of boxes: 1");
			A04Frame.text.updateUI();
		}
		// Adds second box
		else if (b.equals("Create a Box") && A04Frame.Panel1.getBackground() == Color.YELLOW
				&& A04Frame.Panel2.getBackground() == Color.YELLOW) {
			A04Frame.Panel2.setBackground(Color.BLACK);
			A04Frame.Panel2.setVisible(true);
			A04Frame.del.setEnabled(true);
			A04Frame.text.setText("Number of boxes: 2");
			A04Frame.text.updateUI();

		}
		// Adds third box
		else if (b.equals("Create a Box") && A04Frame.Panel2.getBackground() == Color.BLACK
				&& A04Frame.Panel3.getBackground() == Color.BLACK) {
			A04Frame.Panel3.setBackground(Color.YELLOW);
			A04Frame.Panel3.setVisible(true);
			A04Frame.del.setEnabled(true);
			A04Frame.text.setText("Number of boxes: 3");
			A04Frame.text.updateUI();
		}
		// Adds last box and disables the add button
		else if (b.equals("Create a Box") && A04Frame.Panel3.getBackground() == Color.YELLOW
				&& A04Frame.Panel4.getBackground() == Color.YELLOW) {
			A04Frame.Panel4.setBackground(Color.BLACK);
			A04Frame.Panel4.setVisible(true);
			A04Frame.del.setEnabled(true);
			A04Frame.text.setText("Number of boxes: 4");
			A04Frame.text.updateUI();
			A04Frame.add.setEnabled(false);
			A04Frame.del.setEnabled(true);
		}

		// Deletes the fourth box
		if (b.equals("Delete a Box") && A04Frame.Panel4.getBackground() == Color.BLACK) {
			A04Frame.Panel4.setBackground(Color.YELLOW);
			A04Frame.Panel4.setVisible(false);
			A04Frame.add.setEnabled(true);
			A04Frame.text.setText("Number of boxes: 3");
			A04Frame.text.updateUI();

		}
		// Deletes the third box
		else if (b.equals("Delete a Box") && A04Frame.Panel3.getBackground() == Color.YELLOW
				&& A04Frame.Panel4.getBackground() == Color.YELLOW) {
			A04Frame.Panel3.setBackground(Color.BLACK);
			A04Frame.Panel3.setVisible(false);
			A04Frame.add.setEnabled(true);
			A04Frame.text.setText("Number of boxes: 2");
			A04Frame.text.updateUI();

		}
		// Deletes the second box
		else if (b.equals("Delete a Box") && A04Frame.Panel2.getBackground() == Color.BLACK
				&& A04Frame.Panel3.getBackground() == Color.BLACK) {
			A04Frame.Panel2.setBackground(Color.YELLOW);
			A04Frame.Panel2.setVisible(false);
			A04Frame.add.setEnabled(true);
			A04Frame.text.setText("Number of boxes: 1");
			A04Frame.text.updateUI();

		}
		// Deletes the first box and disables delete button
		else if (b.equals("Delete a Box") && A04Frame.Panel1.getBackground() == Color.YELLOW
				&& A04Frame.Panel2.getBackground() == Color.YELLOW) {
			A04Frame.Panel1.setBackground(Color.BLACK);
			A04Frame.Panel1.setVisible(false);
			A04Frame.add.setEnabled(true);
			A04Frame.text.setText("Number of boxes: 0");
			A04Frame.text.updateUI();
			A04Frame.del.setEnabled(false);

		}

	}

}
