package cp213;

import java.awt.Color;

import javax.swing.JButton;

public class A04Buttons extends JButton{

	public A04Buttons(String text) {
		super(text);
		this.setForeground(Color.BLACK);
	}

}
