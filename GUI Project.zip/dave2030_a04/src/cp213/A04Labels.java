package cp213;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JTextArea;

@SuppressWarnings("serial")
public class A04Labels extends JTextArea {

	private Color green = new Color(40, 255, 40);
	int num;
	Font font = new Font("Arial", 1, 14);

	public A04Labels(int num) {
		this.num = num;
		this.setBackground(green);
		this.setFont(font);
	}

}
